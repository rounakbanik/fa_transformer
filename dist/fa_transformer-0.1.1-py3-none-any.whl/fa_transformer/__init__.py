__version__ = '0.1.1'
__name__ = 'fa_transformer'
__author__ = 'Rounak Banik'