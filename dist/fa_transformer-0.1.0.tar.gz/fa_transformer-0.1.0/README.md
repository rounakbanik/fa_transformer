# Factor Analysis Transformers

This is a small library containing custom Factor Analyzer Transformers that are ideal for use in scikit-learn pipelines.